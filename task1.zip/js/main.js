$(document).ready(function(){
    $('.navbar-toggler-icon').click(function(){
        $('.navbar-collapse').collapse('hide');
});
});